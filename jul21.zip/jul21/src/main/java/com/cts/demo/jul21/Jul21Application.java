package com.cts.demo.jul21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jul21Application {

	public static void main(String[] args) {
		SpringApplication.run(Jul21Application.class, args);
	}

}
